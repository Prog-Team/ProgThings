echo Updating system...
apt -y update && apt -y full-upgrade
echo Installing sudo...
apt -y install sudo
echo Installing multimedia codecs...
apt-add-repository 'deb https://www.deb-multimedia.org bullseye main non-free'
apt update -oAcquire::AllowInsecureRepositories=true
apt -y install deb-multimedia-keyring
apt update
echo ""
echo If you see apt errors , try to fix it
echo First setup done! Now , open documentation in archive
echo Press enter to continue

